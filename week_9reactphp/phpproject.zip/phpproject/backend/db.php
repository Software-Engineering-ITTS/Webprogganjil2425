<?php
$host ='localhost';
$dbname = 'phpproject';
$username = 'root';
$password = '';

try {
    $pdo = new PDO(dsn: "mysql:host=$host; dbname=$dbname",
    username:$username,
    password:$password
    );
    $pdo ->setAttribute(
     PDO::ATTR_ERRMODE,
    value:PDO::ERRMODE_EXCEPTION
    );
}catch (PDOException $e){
    die("tidak dapat tersambung :" .$e->getMessage());
}


?>