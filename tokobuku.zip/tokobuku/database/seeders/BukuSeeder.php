<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BukuSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
        // DB::table('bukus')->insert([
            // [
            //     'judul' => 'Harry Potter and the Sorcerer\'s Stone',
            //     'deskripsi' => 'Petualangan penyihir muda Harry Potter.',
            //     'harga' => '100000',
            //     'stok' => 20,
            //     'id_categories' => 1, 
            //     'id_authors' => 1,   
            //     'created_at' => now(),
            //     'updated_at' => now(),
            // ],
            // [
            //     'judul' => '1984',
            //     'deskripsi' => 'Novel distopia klasik oleh George Orwell.',
            //     'harga' => '85000',
            //     'stok' => 15,
            //     'id_categories' => 2, 
            //     'id_authors' => 2,    
            //     'created_at' => now(),
            //     'updated_at' => now(),
            // ],
        // ]);
    }
}
