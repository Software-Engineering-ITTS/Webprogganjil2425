
<?php $__env->startSection('title', 'Toko Buku'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto mt-4">
    <a href="<?php echo e(route('bukus.create')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded">Tambah Buku</a>
    <table class="table-auto w-full mt-4 border">
        <thead>
            <tr class="bg-gray-200">
                <th class="border px-4 py-2">Judul</th>
                <th class="border px-4 py-2">Deskripsi</th>
                <th class="border px-4 py-2">Harga</th>
                <th class="border px-4 py-2">Stok</th>
                <th class="border px-4 py-2">Foto</th>
                <th class="border px-4 py-2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $bukus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="border px-4 py-2"><?php echo e($buku->judul); ?></td>
                <td class="border px-4 py-2"><?php echo e($buku->deskripsi); ?></td>
                <td class="border px-4 py-2"><?php echo e($buku->harga); ?></td>
                <td class="border px-4 py-2"><?php echo e($buku->stok); ?></td>
                <td class="border px-4 py-2">
                <img src="<?php echo e(asset('storage/' . $buku->foto)); ?>" alt="Foto" class="w-20"></td>
                <td class="border px-4 py-2">
                    <a href="/bukus/<?php echo e($buku-> judul); ?>" class="bg-yellow-500 text-white px-2 py-1 rounded">Edit</a>
                    <form action="/bukus/<?php echo e($buku-> judul); ?>" method="POST" class="inline-block">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="bg-red-500 text-white px-2 py-1 rounded" onclick="return confirm('data akan dihapus, apa anda yakin?')">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP VICTUS\OneDrive\Desktop\PemrogramanWeb\Webprogganjil2425\tokobuku\resources\views/bukus/index.blade.php ENDPATH**/ ?>