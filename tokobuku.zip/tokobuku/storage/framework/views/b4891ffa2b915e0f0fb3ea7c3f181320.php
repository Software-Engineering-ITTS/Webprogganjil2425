<nav class="bg-gray-800 p-4 text-white ">
    <div class="container mx-auto flex">
    <a href="<?php echo e(route('bukus.index')); ?>" class="pl-20">Manage Buku</a>
    <a href="<?php echo e(route('pembelian.index')); ?>" class="ml-6">Pembelian Buku</a>
    </div>
</nav>
<?php /**PATH C:\Users\HP VICTUS\OneDrive\Desktop\PemrogramanWeb\Webprogganjil2425\tokobuku\resources\views/components/navbar.blade.php ENDPATH**/ ?>