@extends('layouts.app')
@section('title', 'Toko Buku')

@section('content')
<h1 class="text-6">hello</h1>
@endsection