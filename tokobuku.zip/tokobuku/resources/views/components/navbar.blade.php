<nav class="bg-gray-800 p-4 text-white ">
    <div class="container mx-auto flex">
    <a href="{{ route('bukus.index') }}" class="pl-20">Manage Buku</a>
    <a href="{{ route('pembelian.index') }}" class="ml-6">Pembelian Buku</a>
    </div>
</nav>
