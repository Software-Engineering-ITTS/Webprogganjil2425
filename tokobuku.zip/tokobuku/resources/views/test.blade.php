@extends('admin.app')

@section('content')
<div>
    <p class="mt-2">hello world</p>
</div>
@endsection