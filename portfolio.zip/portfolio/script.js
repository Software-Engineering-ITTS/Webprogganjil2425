

function changeprojek(event) 
{
    event.preventDefault(); 
    var bio = document.getElementById('bio');
    bio.innerHTML = 'untuk projek uas saya ingin membuat sebuah landing page untuk company yang menjual material untuk pembangunan gedung dengan mutu yang tentunya sangat berkualitas, isi dari landing page adalah yang terutama tentang company,alamat dan "highlight" dari produk-produk yang terjual';
    bio.style.textAlign = 'right';
}


function changedatadiri(event)
{
    event.preventDefault();
    var bio = document.getElementById('bio');
    bio.innerHTML = 'berikut adalah data diri sederhana saya untuk mengetahui tentang saya lebih lanjut, silahkan <br>' +
                    '<br>' +
                    'Nama: Muhammad Fahmi <br>' +
                    'Jenis kelamin : he/him <br>' +
                    'Tanggal Lahir: 24 maret 2003 <br>' +
                    'Tempat Lahir: Mojokerto, jawa timur, Indonesia <br>' +
                    'Tempat Tinggal: Mojokerto, jawa timur <br>' +
                    'Hobi: Memprogram, Menggambar <br>' +
                    'Motto: no pain no gain';
}

function changetugas(event) 
{
    event.preventDefault(); 
    var bio = document.getElementById('bio');
    bio.innerHTML = 'berikut adalah beberapa milestone dari tugas yang telah diberikan kepada saya dan telah saya selesaikan dengan usaha saya sendiri : <br>' +
                    '<br>'+
                    'tugas membuat form sederhana menggunakan html <br>' +
                    'tugas membuat portfolio sederhana menggunakan html <br>' +
                    'membuat landing page berita menggunakan html dan css <br>' +
                    'membuat site calculator menggunakan css, html dan javascript <br>'+
                    'membuat sebuah website dari referensi page idstb.org (bootstrap)';
    bio.style.textAlign = 'right';
}
