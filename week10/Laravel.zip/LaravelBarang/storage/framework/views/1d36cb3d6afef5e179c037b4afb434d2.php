<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mufid Nursirot Jati</title>
</head>
<body>
    <h1>Halaman Edit</h1>
    <form action="/mahasiswa/<?php echo e($mahasiswa->NIM); ?>" method="POST">
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="NIM">NIM</label>
            <input type="text" name="NIM" id="NIM" value="<?php echo e($mahasiswa->NIM); ?>">
        </div>
        <div class="mb-3">
            <label for="NAMA">NAMA</label>
            <input type="text" name="NAMA" id="NAMA" value="<?php echo e($mahasiswa->NAMA); ?>">
        </div>
        <div class="mb-3">
            <label for="PRODI">PRODI</label>
            <input type="text" name="PRODI" id="PRODI" value="<?php echo e($mahasiswa->PRODI); ?>">
        </div>
        <div class="mb-3">
            <label for="ALAMAT">ALAMAT</label>
            <input type="text" name="ALAMAT" id="ALAMAT" value="<?php echo e($mahasiswa->ALAMAT); ?>">
        </div>
        <input type="id_fakultas" name="id_fakultas" id="" value="1" hidden>
        <button type="submit" action="/mahasiswa">Submit</button>
    </form>
</body>
</html>
<?php /**PATH D:\Coding Apps\XAMPP\htdocs\Minggu11\myproject\resources\views/edit.blade.php ENDPATH**/ ?>