<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mufid Nursirot Jati</title>
</head>
<body>
    <h1>Form Mahasiswa</h1>
    <form action="/mahasiswa" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="NIM">NIM : </label>
            <input type="text" name="NIM" id="NIM">
        </div>
        <div>
            <label for="NAMA">NAMA : </label>
            <input type="text" name="NAMA" id="NAMA">
        </div>
        <div>
            <label for="PRODI">PRODI : </label>
            <input type="text" name="PRODI" id="PRODI">
        </div>
        <div>
            <label for="ALAMAT">ALAMAT : </label>
            <input type="text" name="ALAMAT" id="ALAMAT">
        </div>
        <input type="id_fakultas" name="id_fakultas" id="" value="1" hidden>
        <button type="submit">SUBMIT</button>
    </form>

    <h2>Daftar Mahasiswa</h2>
    <table border="1" cellpadding="10" cellspacing="0">
        <thead>
            <tr>
                <th>NIM</th>
                <th>Nama</th>
                <th>Prodi</th>
                <th>Alamat</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($mhs->NIM); ?></td>
                <td><?php echo e($mhs->NAMA); ?></td>
                <td><?php echo e($mhs->PRODI); ?></td>
                <td><?php echo e($mhs->ALAMAT); ?></td>
                <td>
                <button type="button" onclick="window.location.href='/mahasiswa/<?php echo e($mhs->NIM); ?>/edit'">Edit</button>
                    <form action="/mahasiswa/<?php echo e($mhs->NIM); ?>" method="POST" style="display: inline;">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" onclick="return confirm('Yakin ingin menghapus?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH D:\Coding Apps\XAMPP\htdocs\Minggu11\myproject\resources\views/index.blade.php ENDPATH**/ ?>