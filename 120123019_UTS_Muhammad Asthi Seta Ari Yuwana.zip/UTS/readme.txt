Gambaran awal project UAS : Aplikasi Medsos Sederhana 

Fitur : 
- Create Post
- Like Post
- Delete Post
- Edit Profile

Link publish portfolio : https://akuradiary.github.io
Link Repo Github Kelas : https://github.com/Software-Engineering-ITTS/Webprogganjil2425/tree/1201230019_Seta