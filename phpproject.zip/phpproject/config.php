<?php
define('DB_HOST','localhost');//alamat server mysql/mariadb
define('DB_USER','root');//username database
define('DB_PWD','');//password database
define('DB_NAME','phpproject');//nama database (schema)
?>