<html>
    <head>
        <title>PHP CRUD PROJECT</title>
        <link rel="stylesheet" href="style.css"/>
    </head>
    <body>
    <div>
        <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="tambahdata.php">Tambah Data</a></li>
        <li><a href="lihatdata.php">Lihat Data</a></li>
        </ul>
    </div>
