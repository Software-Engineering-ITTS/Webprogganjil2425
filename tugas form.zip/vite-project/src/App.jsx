import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
// import './App.css'

function App() {
  const [form, setForm] = useState({ username: "", password: "" })
  const [errors, setError] = useState({});
  const handledChange = (e) =>{
  const {name,value} = e.target
  setForm({
    ...form,
    [name] : value
  });
  }
  const onsubmit = (e) => {
    e.preventDefault()
    const errors = validateForm(form) 
    // console.log(errors)
    setError(errors);
    if(Object.keys(errors).length === 0) {
      console.log("call api post")
    }
    //console.log(form)
  }

  const validateForm = (form) => {
    const errors = {};
    if(!form.username.trim()) {
      errors.username = "username is required"
    }
    if(!form.password){
      errors.password = "password is required"
    }
    else if(form.password.length < 8){
      errors.password = "minimal password 8 karakter"
    }
    return errors;
  }

  return (
    <>
    <form onSubmit={onsubmit}>
      <div className="container" style={{ backgroundColor: 'aqua' }}>
        <h1 className="judul" style={{ textAlign: 'center', backgroundColor: 'red' }}>
          Formulir Laporan Keuangan
        </h1>
        <p style={{ textAlign: 'center' }}>Toko Madura</p>
        <div className="isi"></div>
        <br />
        <br />
        <b>username:</b>
        <input type="text" id='username' name='username' onChange={handledChange}/>
        <span>{errors.username}</span>
        <br />
        <br />
        <b>password :</b>
        <input type="password" id='password' name="password" onChange={handledChange}/>
        <span>{errors.password}</span>
        <br />
        <br />
        <input type="radio" className="radio" name="jabatan" />
        <b>Owner</b>
        <input type="radio" className="radio" name="jabatan" />
        <b>Pegawai</b>
        <br />
        <br />
        <br />
        <textarea placeholder="Keterangan"></textarea>
        <br />
        <br />
        <input type="checkbox" id="foodDrink" name="foodDrink" value="Food & Drink" />
        <label htmlFor="foodDrink"> Makanan & Minuman</label><br />
        <input type="checkbox" id="sembako" name="sembako" value="Sembako" />
        <label htmlFor="sembako"> Sembako </label><br />
        <input type="checkbox" id="perlengkapan" name="perlengkapan" value="Perlengkapan" />
        <label htmlFor="perlengkapan"> Perlengkapan</label><br />
        <br />
        <br />
        <div className="dropdown">
          <button
            className="btn btn-secondary dropdown-toggle"
            type="button"
            data-bs-toggle="dropdown"
            aria-expanded="false"
          >
            Pilih
          </button>
          <ul className="dropdown-menu">
            <li>
              <a className="dropdown-item" href="#">
                Expense
              </a>
            </li>
            <li>
              <a className="dropdown-item" href="#">
                Income
              </a>
            </li>
          </ul>
        </div>
        <br />
        <br />
        <button type="submit">Submit</button>
      </div>
      </form>
    </>
  )
}

export default App
